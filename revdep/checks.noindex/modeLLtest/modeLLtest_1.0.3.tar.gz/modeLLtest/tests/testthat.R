library(testthat)
library(modeLLtest)

test_check("modeLLtest")

# modeLLtest 1.0.3

* Updated typos in data files and cleaned documentation

# modeLLtest 1.0.2

* Added a `NEWS.md` file to track changes to the package
* Updated documentation 

# modeLLtest 1.0.1

* JOSS-accepted release. 
* Added minor changes to increase community access such as CONTRIBUTING file, CODE_OF_CONDUCT file, and issues 

# modeLLtest 1.0.0

* Initial CRAN release

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Please cite: Scogin et al., (2019). modeLLtest: An R Package for Unbiased
                        Model Comparison using Cross Validation. Journal of Open Source Software,
                        4(41), 1542, https://doi.org/10.21105/joss.01542")
}
